$(document).ready(function(){

    setTimeout(function(){
        $(".loader").removeClass("active");
    },2500)
	
    isHidden = 0;

	$('.scroll').click( function(){
        var scroll_el = $(this).attr('href');
        if ($(scroll_el).length != 0) {
            $('html, body').animate({ scrollTop: $(scroll_el).offset().top - 100 }, 500);
        }
        return false;
    });

    $(".mail").submit(function() {
        $.ajax({
            type: "POST",
            url: "mail.php",
            data: $(this).serialize()
        }).done(function() {
            $(".mail").trigger('reset')
            $.fancybox.close();
            alert('Спасибо за заявку! Мы скоро с вами свяжемся!');
        });
        return false;
    });

    $(".hide").click(function(){
        $(this).toggleClass("active");
        if($(this).hasClass("active")){
            $(this).closest(".program__input-container").find("input").attr('type', 'password');
        } else{
            $(this).closest(".program__input-container").find("input").attr('type', 'text');
        }
    })

    $("#radio-3-1").click(function(){
        if(!$(this).prop("checked")){
            $("#radio-3-1")[0].checked = 0;
            $("#radio-3-2")[0].checked = 0;
        }
    })
    $("#radio-3-2").click(function(){
        if($(this).prop("checked")){
            $("#radio-3-1")[0].checked = 1;
            $("#radio-3-2")[0].checked = 2;
        }
    })
    $("#radio-2-8").change(function(){
        if($(this).prop("checked")){
            $(".telegram-block").addClass("active")
        } else{
            $(".telegram-block").removeClass("active")
        }
    })
    $("#radio-2-4").change(function(){
        if($(this).prop("checked") && !isHidden){
            $.fancybox.open({
                src: $('.popup-warning'),
                type: "inline"
            });
        }
    })
    $("[name='radio-1[]']").change(function(){
        var checkValues = $('[name="radio-1[]"]:checked').map(function() {
            return $(this).val();
        }).get();
        if(checkValues.length > 0){
            $(".btn-start").removeAttr("disabled")
        } else{
            $(".btn-start").attr("disabled","disabled")
        }
    })
	$(".pro").click(function(e){
        e.preventDefault();
        $.fancybox.open({
            src: $('.popup-pro'),
            type: "inline"
        });
    })

    $(".popup .btn, .popup__hide").click(function(){
        $.fancybox.close();
    })

    $(".popup__hide").click(function(){
        isHidden = 1;
    })

    $(".btn-start").click(function(){
        $(this).parent().addClass("active");
    })
})