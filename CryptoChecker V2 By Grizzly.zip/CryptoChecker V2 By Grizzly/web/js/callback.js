eel.expose(setpercent)
function setpercent(percent) {
    document.getElementById("percenttext").innerHTML = percent
    document.getElementById("percent").style.width = percent
}

eel.expose(setvalue)
function setvalue(elemid, val) {
    document.getElementById(elemid).innerHTML = val;
}

eel.expose(sync);
function sync(data) {
    var qwer = ['radio-1-1', 'radio-1-2', 'radio-1-3', 'radio-1-4', 'radio-1-5', 'radio-1-6', 'radio-1-7', 'radio-1-8', 'radio-1-9', 'radio-1-10', 'radio-1-11', 'radio-1-12', 'radio-1-13', 'radio-1-14', 'radio-2-1', 'radio-2-2', 'radio-2-3', 'radio-2-4', 'radio-2-5', 'radio-2-6', 'radio-2-7', 'radio-2-8', 'userid', 'token', 'radio-3-1', 'radio-3-2', 'radio-4-1', 'radio-4-2', 'radio-4-3', 'radio-5-1', 'radio-5-2']
    for (elem in data) {
        if (qwer[elem] == "userid" || qwer[elem] == "token") {
            document.getElementById(qwer[elem]).value = data[elem]
        } else {
            document.getElementById(qwer[elem]).checked = data[elem]
        }
    }
}

eel.expose(getdata);
function getdata() {
    return [document.getElementById('radio-1-1').checked, document.getElementById('radio-1-2').checked, document.getElementById('radio-1-3').checked, document.getElementById('radio-1-4').checked, document.getElementById('radio-1-5').checked, document.getElementById('radio-1-6').checked, document.getElementById('radio-1-7').checked, document.getElementById('radio-1-8').checked, document.getElementById('radio-1-9').checked, document.getElementById('radio-1-10').checked, document.getElementById('radio-1-11').checked, document.getElementById('radio-1-12').checked, document.getElementById('radio-1-13').checked, document.getElementById('radio-1-14').checked, document.getElementById('radio-2-1').checked, document.getElementById('radio-2-2').checked, document.getElementById('radio-2-3').checked, document.getElementById('radio-2-4').checked, document.getElementById('radio-2-5').checked, document.getElementById('radio-2-6').checked, document.getElementById('radio-2-7').checked, document.getElementById('radio-2-8').checked, document.getElementById('userid').value, document.getElementById('token').value, document.getElementById('radio-3-1').checked, document.getElementById('radio-3-2').checked, document.getElementById('radio-4-1').checked, document.getElementById('radio-4-2').checked, document.getElementById('radio-4-3').checked, document.getElementById('radio-5-1').checked, document.getElementById('radio-5-2').checked]
    //shitcode
}

function startcheck() {
    eel.main()();
}